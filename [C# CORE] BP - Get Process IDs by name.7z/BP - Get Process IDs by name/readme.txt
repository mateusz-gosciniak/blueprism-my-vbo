dotnet new console
dotnet run