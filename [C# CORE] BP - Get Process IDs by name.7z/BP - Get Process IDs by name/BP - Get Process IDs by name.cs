﻿using System;
using System.Data;
using System.Diagnostics;

namespace Desktop
{
    class Program
    {
        static void Main(string[] args)
        {
            // input var 
            string Process_Name = "iexplore.exe";
            string Title_Name = "LexisNexis - Internet Explorer";
            // output var
            int Process_ID_by_Title_Name;
            DataTable Process_IDs;
            
            // start code for BP
            Process_ID_by_Title_Name = -1;
            Process_IDs = new DataTable();

            if(Process_Name.EndsWith(".exe")){
                Process_Name = Process_Name.Remove(Process_Name.LastIndexOf('.'), 4);
            }

            Process_IDs.Columns.Add("id", typeof(Int32));
            Process_IDs.Columns.Add("title", typeof(String));
            Process[] Processes = Process.GetProcessesByName(Process_Name);
            if (!string.IsNullOrEmpty(Title_Name)){
                foreach (var p in Processes){
                    DataRow row = Process_IDs.NewRow();
                    row["id"] = p.Id;
                    row["title"] = p.MainWindowTitle;
                    Process_IDs.Rows.Add(row);
                    
                    if (string.Equals(p.MainWindowTitle, Title_Name)){
                        Process_ID_by_Title_Name = p.Id;
                    }
                }
            }else{
                foreach (var p in Processes){
                    DataRow row = Process_IDs.NewRow();
                    row["id"] = p.Id;
                    row["title"] = p.MainWindowTitle;
                    Process_IDs.Rows.Add(row);
                }
            }
            // end code for BP

            // info
            Console.WriteLine($"Process_Name: {Process_Name}");
            Console.WriteLine("size: " + Processes.Length.ToString());
            foreach (var p in Processes)
            {
                Console.WriteLine($"p name: {p.MainWindowTitle}, id: {p.Id}");
            }
        } 
    }
}
